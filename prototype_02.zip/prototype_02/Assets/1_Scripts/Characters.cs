﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    /// <summary>
    /// Parent script of Hero and Player.
    /// </summary>
    public class Characters : Entity
    {
        /// <summary>
        /// Calculate a Vector2 orientation based on the facing direction.
        /// </summary>
        /// <param name="dir">Facing direction of the character.</param>
        /// <returns></returns>
        public Vector2 CalculateOrientation(FacingDirection dir)
        {
            return new Vector2(Mathf.Sin((float)dir * Mathf.PI / 2), Mathf.Cos((float)dir * Mathf.PI / 2)); //Return a Vector2 normalized pointing North, East, South or West.
        }

        /// <summary>
        /// Select the animator's layer you want to activate. It set's the layer's weight to 1, and the other's to 0.
        /// </summary>
        /// <param name="layerName">Name of the layer you want to activate.</param>
        /// <param name="animator">Animator controller.</param>
        public void ActivateLayer(string layerName, Animator animator)
        {
            // Set all the layers weight to 0.
            for (int i = 0; i < animator.layerCount; i++)
            {
                animator.SetLayerWeight(i, 0);
            }
            
            // Set the weight of the layer you want to 1.
            animator.SetLayerWeight(animator.GetLayerIndex(layerName), 1);
        }

        /// <summary>
        /// Manage to switch between moving layer and idle layer in the animator.
        /// </summary>
        /// <param name="animator">Animator of the game object</param>
        /// <param name="walkingLayername">Name of the walking layer</param>
        /// <param name="idleLayerName">Name of the idling layer</param>
        /// <param name="isMoving">Check if the character is moving</param>
        /// <param name="dir">Direction (enum)</param>
        /// <param name="animSpeed">Speed factor of the animation</param>
        public void HandleLayers(Animator animator, string walkingLayerName, string idleLayerName, bool isMoving, FacingDirection dir, float animSpeed)
        {
            animator.SetFloat("x", CalculateOrientation(dir).x); // Set the float x of the animator to the x of the calculated orientation.

            animator.SetFloat("y", CalculateOrientation(dir).y); // Set the float y of the animator to the y of the calculated orientation.

            // We want to activate the layer with moving sprites if the character is moving.
            if (isMoving) // Verify if the character is moving.
            {
                ActivateLayer(walkingLayerName, animator); // Activate the walking layer.

                animator.SetFloat("animSpeed", animSpeed); // Adjust anim speed to the speed of the Character.
            }
            else if (!isMoving)
            {
                ActivateLayer(idleLayerName, animator); // Activate idle layer.
            }
        }

        /// <summary>
        /// Manage to switch between moving layer and idle layer in the animator. Overload with Vector2 remplacing FacingDirection enum.
        /// </summary>
        /// <param name="animator">Animator of the game object</param>
        /// <param name="walkingLayername">Name of the walking layer</param>
        /// <param name="idleLayerName">Name of the idling layer</param>
        /// <param name="isMoving">Check if the character is moving</param>
        /// <param name="dir">Direction (Vector2)</param>
        /// <param name="animSpeed">Speed factor of the animation</param>
        public void HandleLayers(Animator animator, string walkingLayerName, string idleLayerName, bool isMoving, Vector2 vector, float animSpeed)
        {
            animator.SetFloat("x", vector.x); // Set the float of the x of the animator to vector.x

            animator.SetFloat("y", vector.y); // Set the float of the y of the animator to vector.y

            // We want to activate the layer with moving sprites if the character is moving.
            if (isMoving) // Verify if the character is moving.
            {
                ActivateLayer(walkingLayerName, animator); // Activate the walking layer.

                animator.SetFloat("animSpeed", animSpeed); // Adjust anim speed to the speed of the Character.
            }
            else if (!isMoving)
            {
                ActivateLayer(idleLayerName, animator); // Activate idle layer.
            }
        }
    }
}