﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    [CreateAssetMenu(fileName = "New Environment Entity", menuName = "Environment Entity")]
    public class EnvironmentEntity : ScriptableObject
    {
        /* USED TO INITIALIZE ALL THE VINCINITY INFORMATION OF THE ENTITIES
         * This scriptableobject script is used to create ressources to initialize vincinity information.
         */

        /// <summary>
        /// Base interest value of the object
        /// </summary>
        [SerializeField]private int interestValue;
        /// <summary>
        /// PARAMETER : Base interest value of the object
        /// </summary>
        public int InterestValue { get { return interestValue; } }

        /// <summary>
        /// Base danger value of the object
        /// </summary>
        [SerializeField] private int dangerValue;
        /// <summary>
        /// PARAMETER : Base danger value of the object
        /// </summary>
        public int DangerValue { get { return dangerValue; } }

        /// <summary>
        /// Is the entity corrupted ?
        /// </summary>
        [SerializeField] private bool corruption;
        /// <summary>
        /// PARAMETER : Is the entity corrupted ?
        /// </summary>
        public bool Corruption { get { return corruption; } }

        /// <summary>
        /// Type of the entity.
        /// </summary>
        [SerializeField] private VincinityType type;
        /// <summary>
        /// PARAMETER : Type of the entity.
        /// </summary>
        public VincinityType Type { get { return type; } }
    }
}