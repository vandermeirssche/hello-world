﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

namespace ZeldaLike.Vadnir 
{
    /// <summary>
    /// Original class used on every entities the Hero will analyze or interact with.
    /// </summary>
    [System.Serializable]
    public class Vincinity 
    {
        /// <summary>
        /// GameObject which carries this vincinity information.
        /// </summary>
        public GameObject vincinityObject;

        /// <summary>
        /// Hero's gameObject, used to calculate information related to the distance between the entity and the Hero.
        /// </summary>
        public GameObject heroObject;

        /// <summary>
        /// Player's GameObject, used to calculate information.
        /// </summary>
        public GameObject playerObject;

        /// <summary>
        /// Type of the entities, used to adapt hero's behaviours according to the entity type.
        /// </summary>
        public VincinityType type;

        /// <summary>
        /// Base interest value of the entity.
        /// </summary>
        public int interestValue;

        /// <summary>
        /// Calculated interest value of the entity, using the base value, and the distance from the hero.
        /// </summary>
        public float interest;

        //public float Interest { get { return interest; } } // used when Vincinity.interest is private.

        /// <summary>
        /// Base danger value of the entity.
        /// </summary>
        public int dangerValue;

        /// <summary>
        /// Calculated danger value of the entity, using the base value, and the distance from the hero.
        /// </summary>
        public float danger;

        //public float Danger { get { return danger; } } // used when Vincinity.danger is private.

        /// <summary>
        /// Is the entity corrupted or not ?
        /// </summary>
        public bool corrupted;

        /// <summary>
        /// Does the entity have been visited by the Hero or not ?
        /// </summary>
        public bool visited;

        /// <summary>
        /// Distance between the entity and the Hero.
        /// </summary>
        public float distanceFromPlayer;

        /// <summary>
        /// Distance between the entity and the Player. Useless for now.
        /// </summary>
        public float distanceFromHero;

        /// <summary>
        /// Call a new Vincinity Entity.
        /// </summary>
        /// <param name="_type">Type of the Vincinity entity.</param>
        /// <param name="_self">GameObject of the Vincinity entity.</param>
        /// <param name="_hero">GameObject of the Hero.</param>
        /// <param name="_player">gameObject of the Player.</param>
        /// <param name="_interest">Base interest of the Vincinity entity.</param>
        /// <param name="_danger">Base danger of the Vincinity entity.</param>
        /// <param name="_corruption">Corruption of the Vincinity entity.</param>
        public Vincinity(VincinityType _type, GameObject _self, GameObject _hero, GameObject _player, int _interest, int _danger, bool _corruption)
        {
            type = _type; // Set up the type from the method.
           
            vincinityObject = _self; // Set up the GameObject of the entity from the method.

            heroObject = _hero;  // Set up the GameObject of the Hero from the method.

            playerObject = _player; // Set up the GameObject of the Player from the method.

            interestValue = _interest; // Set up the base interest from the method.

            dangerValue = _danger; // Set up the base danger from the method.

            corrupted = _corruption; // Set up the base corruption from the method.
        }

        /// <summary>
        /// Call a new Vincinity Entity. Overload used for initialization with a Scriptable Object.
        /// </summary>
        /// <param name="_type">Type of the Vincinity entity.</param>
        /// <param name="_interest">Base interest of the Vincinity entity.</param>
        /// <param name="_danger">Base danger of the Vincinity entity.</param>
        /// <param name="_corruption">Corruption of the Vincinity entity.</param>
        public Vincinity(VincinityType _type, int _interest, int _danger, bool _corruption)
        {
            type = _type; // Set up the type from the method.

            interestValue = _interest; // Set up the base interest from the method.

            dangerValue = _danger; // Set up the base danger from the method.

            corrupted = _corruption; // Set up the base corruption from the method.
        }

        /// <summary>
        /// Update calculated information of the Vincinity class.
        /// </summary>
        public void Update()
        {
            distanceFromHero = Vector2.Distance(vincinityObject.transform.position, heroObject.transform.position); // Calculate distance of the entity from the Hero.

            distanceFromPlayer = Vector2.Distance(vincinityObject.transform.position, playerObject.transform.position); // Calculate distance of the entity from the Player.

            CalculateDanger();

            CalculateInterest();
        }

        /// <summary>
        /// Calculate the danger based on the distance of the entity from the Hero.
        /// </summary>
        public void CalculateDanger()
        {
            float calculation = -1 * 5 * distanceFromHero / dangerValue + 10 + dangerValue / distanceFromHero; // y = -5*x/d + 10 + d/x  where x equals the distance, and d the base danger.

            danger = dangerValue == 0 ? 0 : calculation > 150 ? 150 : calculation > 0 ? calculation : 0; // limit the value in the range : [0 ; 150].
        }

        /// <summary>
        /// Calculate the interest based on the distance of the entity from the Hero.
        /// </summary>
        public void CalculateInterest()
        {
            // y = -((i/(x+i))^i/x * log(x) )^2 * (20 - i)  where i x equals the distance, and i the base interest.
            interest = -1 * Mathf.Pow(Mathf.Pow((interestValue / (distanceFromHero + interestValue)), interestValue / distanceFromHero) * Mathf.Log(distanceFromHero), 2) * (20 - interestValue);
        }
    }
}