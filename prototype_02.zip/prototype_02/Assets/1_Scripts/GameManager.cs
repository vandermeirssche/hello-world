﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    public class GameManager : MonoBehaviour
    {
        public static GameState state = new GameState();

        void Update()
        {

        }
    }

    public class GameState
    {
        /// <summary>
        /// List of all the entities of the game.
        /// </summary>
        private List<Entity> entities = new List<Entity>();
        /// <summary>
        /// List of all the entities of the game.
        /// </summary>
        public List<Entity> Entities { get { return entities; } }

        /// <summary>
        /// Register the entities
        /// </summary>
        /// <param name="ent">Entity you want to register</param>
        public void RegisterEntity(Entity ent)
        {
            entities.Add(ent);
        }

        /// <summary>
        /// Register the entities
        /// </summary>
        /// <param name="ent">Entity you want to unregister</param>
        public void UnregisterEntity(Entity ent)
        {
            entities.Remove(ent);
        }

        public void CallPlayerActivity()
        {
            for (int i = 0; i < entities.Count; i++)
            {
                entities[i].PlayerActivity();
            }
        }

        public void CallAmnesiaSpell()
        {
            for (int i = 0; i < entities.Count; i++)
            {
                entities[i].AmnesiaSpell();
            }
        }
    }
}