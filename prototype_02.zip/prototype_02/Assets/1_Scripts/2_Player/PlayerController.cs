﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    public class PlayerController : Characters
    {
        /// <summary>
        /// PARAMETER : Is the player moving ?
        /// </summary>
        [SerializeField] private bool PlayerIsMoving {get { return playerMovingInput.x != 0 || playerMovingInput.y != 0; } }

        /// <summary>
        /// Is the player in the material world ?
        /// </summary>
        [SerializeField] private bool playerIsPhysical = false;
        /// <summary>
        /// PARAMETER : Is the player in the material world ?
        /// </summary>
        public bool PlayerIsPhysical { get { return playerIsPhysical; } set { playerIsPhysical = value; } }

        /// <summary>
        /// Player's moving direction
        /// </summary>
        private Vector2 playerDirection;

        /// <summary>
        /// Player's Speed
        /// </summary>
        [SerializeField] private float playerSpeed;

        [Header("Spirituality informations")]

        /// <summary>
        /// Mana gauge's actual value of the player.
        /// </summary>
        [SerializeField] private float playerManaGaugeValue;
        /// <summary>
        /// PARAMETER : Mana gauge's actual value of the player.
        /// </summary>
        public float PlayerManaGaugeValue
        {
            get
            {
                return playerManaGaugeValue;
            }
            set
            {
                // Limit the value of the Mana gauge inside : [0 ; palyerManaGaugeMaxValue].
                if (value > playerManaGaugeMaxValue)
                    playerManaGaugeValue = playerManaGaugeMaxValue;
                else if (value < 0)
                    playerManaGaugeValue = 0;
                else
                    playerManaGaugeValue = value;

            }
        }

        /// <summary>
        /// Max value of the mana gauge of the player
        /// </summary>
        [SerializeField] private float playerManaGaugeMaxValue;
        /// <summary>
        /// PARAMETER : Max value of the mana gauge of the player
        /// </summary>
        public float PlayerManaGaugeMaxValue { get { return playerManaGaugeMaxValue; } set { playerManaGaugeMaxValue = value; } }

        /// <summary>
        /// Player Mana's decreasing factor when in the physical world.
        /// </summary>
        [SerializeField] private float playerManaDecreasingFactor;

        /// <summary>
        /// Player mana's increasing factor when in the spritual world.
        /// </summary>
        [SerializeField] private float playerManaIncreasingFactor;

        /// <summary>
        /// Player's facing direction.
        /// </summary>
        [SerializeField] protected FacingDirection playerFacingDirection;

        /// <summary>
        /// Monving inputs of the player.
        /// </summary>
        protected Vector2 playerMovingInput;

        /// <summary>
        /// Player's animator.
        /// </summary>
        [SerializeField] private Animator playerAnimator;

        /// <summary>
        /// Player's rigidbody2D.
        /// </summary>
        [SerializeField] private Rigidbody2D playerRigidbody;

        /// <summary>
        /// Player's colldier.
        /// </summary>
        [SerializeField] private BoxCollider2D playerPhysicalBoxCollider;

        /// <summary>
        /// Player's entity information script.
        /// </summary>
        [SerializeField] private EntityInformation playerEntityInformation; 

        void Start()
        {
            playerManaGaugeValue = playerManaGaugeMaxValue; // initialize the Mana gauge value.

            playerEntityInformation.enabled = false; // Disable the entity information of the player because he's not physical.
        }

        void Update()
        {
            //CurrentDirection(playerMovingInput, playerFacingDirection); // à débugger
            PlayerDirection(); 

            if (PlayerIsPhysical) // Handle the layer with the physical sprites and animations if the player is physical.
                HandleLayers(playerAnimator, "PlayerWalkLayer", "PlayerIdleLayer", PlayerIsMoving, playerFacingDirection, 1);
            else // Handle layer with the spiritual sprites and animations if the player isn't physical.
                HandleLayers(playerAnimator, "PlayerGhostWalkLayer", "PlayerGhostIdleLayer", PlayerIsMoving, playerFacingDirection, 1);

            GetInputs();

            PlayerManaGauge();
        }

        public void FixedUpdate()
        {
            PlayerMove();
        }

        /// <summary>
        /// Get player's inputs.
        /// </summary>
        public void GetInputs()
        {
            playerMovingInput = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical")); // Use the unity inputs system to get information about the movement of the player.


            if(Input.GetKeyDown(KeyCode.E)) // Press E to switch between spiritual world and physical world..
            {
                if((!playerIsPhysical && playerManaGaugeValue > 1.5) || (playerIsPhysical)) // verify if the player is spritual and got enough mana, or if he's physical.
                    PlayerCastSpellMaterialAspect();
            }

            // DEBUG ONLY : reset all the vincinity.visited of the entities.
            if (Input.GetKeyDown(KeyCode.A)) // Press A
            {
                if(playerManaGaugeValue > 1) // Verify if the player has enough mana.
                {
                    PlayerCastSpellAmnesia(); // Call the event.

                    playerManaGaugeValue -= 1; // Cost in mana.
                }
            }
        }

        /// <summary>
        /// Method used to move the player.
        /// </summary>
        public void PlayerMove()
        {
            playerRigidbody.velocity = playerMovingInput.normalized * playerSpeed; // move the player using velocity and the playerspeed var.
        }

        /// <summary>
        /// Calculate the player's direction.
        /// </summary>
        public void PlayerDirection()
        {
            if (playerMovingInput.y > 0 && Mathf.Abs(playerMovingInput.y) > Mathf.Abs(playerMovingInput.x))
            {
                playerFacingDirection = FacingDirection.North; // North
            }

            if (playerMovingInput.x > 0 && Mathf.Abs(playerMovingInput.x) > Mathf.Abs(playerMovingInput.y))
            {
                playerFacingDirection = FacingDirection.East; // East
            }

            if (playerMovingInput.y < 0 && Mathf.Abs(playerMovingInput.y) > Mathf.Abs(playerMovingInput.x))
            {
                playerFacingDirection = FacingDirection.South; // South
            }

            if (playerMovingInput.x < 0 && Mathf.Abs(playerMovingInput.x) > Mathf.Abs(playerMovingInput.y))
            {
                playerFacingDirection = FacingDirection.West; // West
            }
        }

        /// <summary>
        /// Spell : switch between physical and spiritual world.
        /// </summary>
        public void PlayerCastSpellMaterialAspect()
        {
            playerIsPhysical = !playerIsPhysical; // Switch his state.

            playerEntityInformation.enabled = playerIsPhysical; // Enable or disable the entity information of the player whether if he is pysical or not.

            playerPhysicalBoxCollider.enabled = playerIsPhysical; // Enable or disable the colldier2D of the player whether if he is pysical or not.

            GameManager.state.CallPlayerActivity(); // Call the event.
        }

        /// <summary>
        /// DEBUG ONLY Spell : reset the vincinity.visited of all entities.
        /// </summary>
        public void PlayerCastSpellAmnesia()
        {
            GameManager.state.CallAmnesiaSpell(); // Call the event.
        }

        /// <summary>
        /// Behaviour of the mana gauge whether the player is physical or spiritual.
        /// </summary>
        public void PlayerManaGauge()
        {
            if(playerIsPhysical) // Verify if the player is physical.
            {
                PlayerManaGaugeValue -= Time.deltaTime * playerManaDecreasingFactor; // Decrease the mana overtime if the player is physical.

                if (playerManaGaugeValue == 0) 
                    PlayerCastSpellMaterialAspect(); // if the gauge hits 0, set the player Spiritual.
            }
            else
            {
                PlayerManaGaugeValue += Time.deltaTime * playerManaIncreasingFactor; // inscrease the mana overtime if the player is spiritual.
            }
        }
    }
}