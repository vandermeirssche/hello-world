﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    public class EntityInformation : Entity
    {
        /* This script is on every object that need to be analyzed by the Hero.
         * It gathers information helping the Hero to interact witht the whole vincinity.
         * DO NOT ADD IT TO USELESS OBJECTS
         */

        /// <summary>
        /// Scriptable object stocking base information about the Entity.
        /// </summary>
        [SerializeField] private EnvironmentEntity environmentEntityInfo;

        /// <summary>
        /// Information about the object stocked is the Vincinity class.
        /// </summary>
        [SerializeField] private Vincinity vincinityInfo;
        /// <summary>
        /// PARAMETER : Information about the object stocked is the Vincinity class.
        /// </summary>
        public Vincinity VincinityInfo { get { return vincinityInfo; } set { vincinityInfo = value; } }

        void Awake()
        {
            //INITIALIZATION OF THE OBJECT'S INFORMATION
            vincinityInfo = InitializeVincinityFromSCO(environmentEntityInfo); // Initialize information from the Scriptable Object

            vincinityInfo.vincinityObject = gameObject; // Initialize gameobject variable (Cf. Vincinity Class)

            vincinityInfo.heroObject = GameObject.Find("Hero"); // Initialize Hero's gameobject variable (Cf. Vincinity Class)

            vincinityInfo.playerObject = GameObject.Find("Player"); // Initialize Player's gameobject variable (Cf. Vincinity Class)
        }

        private void Start()
        {
            vincinityInfo.Update(); // Called to calculate information.
        }

        void Update()
        {
            vincinityInfo.Update(); // Called to update calculated information.
        }

        /// <summary>
        /// DEBUG : Reset 'visited' variable.
        /// </summary>
        public override void AmnesiaSpell()
        {
            vincinityInfo.visited = false;
        }

        /// <summary>
        /// Initialize the Vincinity class var from a scriptable object.
        /// </summary>
        /// <param name="envEnt">Scriptable Object initializing information.</param>
        /// <returns>Return the Vincinity information got from the scriptable object.</returns>
        public Vincinity InitializeVincinityFromSCO(EnvironmentEntity envEnt)
        {
            return new Vincinity(envEnt.Type, envEnt.InterestValue, envEnt.DangerValue, envEnt.Corruption);
        }
    }
}