﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    //Vincinity Enumerators
    /// <summary>
    /// Type of the Vincinity entities. 0 = Ennemy, 1 = Ally, 2 = Neutral, 3 = Object, 4 = Player, 5 = Hero.
    /// </summary>
    public enum VincinityType { Ennemy, Ally, Neutral, Object, Player, Hero };
    /// <summary>
    /// Define the var you want to test inside a List of Vincinity class var. 0 = Interest, 1 = Danger.
    /// </summary>
    public enum VincinityComparator { Interest, Danger};

    //Facing Direction
    /// <summary>
    /// Direction of the character. 0 = North, 1 = East, 2 = South, 3 = West.
    /// </summary>
    public enum FacingDirection { North, East, South, West}
}
