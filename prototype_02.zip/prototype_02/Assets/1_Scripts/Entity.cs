﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    public abstract class Entity : MonoBehaviour
    {
       /* Parent script of most of the entities scripts.
        */
        
        private void OnEnable()
        {
            GameManager.state.RegisterEntity(this); // Add the entity to the global list of all the entities.
        }

        private void OnDisable()
        {
            GameManager.state.UnregisterEntity(this); // Add the entity to the global list of all the entities.
        }

        public virtual void PlayerActivity()
        {

        }

        public virtual void AmnesiaSpell()
        {

        }
    }
}