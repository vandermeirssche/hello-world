﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ZeldaLike.Vadnir; // Needed to use stuff of the project.


public static class VincintySort {

    /// <summary>
    /// Sort with the Bubble Algorithm a list of Vincinity class var, according to a VincinityComparator.
    /// </summary>
    /// <param name="list">List you want to Sort</param>
    /// <param name="vc">Element you want to Compare.</param>
    /// <returns>Return the List sorted</returns>
    public static List<Vincinity> SortByVincinityComparator(this List<Vincinity> list, VincinityComparator vc) // using "this" prevents the declaration of the list when you call the function.
    {
        List<Vincinity> sortedList = list; // Get a new list from the list you want to sort.

        bool isValid = false; // Var to test if in the while loop the algorithm manage to change something. It's set up to false to enter the loop.

        while(!isValid) // Check if the algorithm change something, which means it isn't fully sorted yet.
        {
            isValid = true; // Initialize the validation var.

            //Check all values in the list with its next superior neighbour. 
            for (int i = 0; i < sortedList.Count-2; i++) // To avoid an out of range exception because of the sortedList[i+1] le loop is limited to sortedList.Count-2.
            {
                if(vc == VincinityComparator.Danger) // In case it's according to the Danger that the vincinity stuff needs to be sorted
                {
                    // Test if the value of the tested vincinity is inferior or superior to its neighbour. In this second case, we swap them.
                    if (sortedList[i].danger > sortedList[i + 1].danger) //In case of the value is superior to its neighbour.
                    {
                        sortedList.Insert(i, sortedList[i + 1]); // Insert at its order a new vincinity equal to the neighbour.

                        sortedList.RemoveAt(i + 2); // Remove the neighbour because we insert a new one at the right order.

                        isValid = false; // because we modified something, we need at least one more loop to check everything it's ok.
                    }
                }
                if (vc == VincinityComparator.Interest)// In case it's according to the Interest that the vincinity stuff needs to be sorted
                {
                    // Test if the value of the tested vincinity is inferior or superior to its neighbour. In this second case, we swap them.
                    if (sortedList[i].interest > sortedList[i + 1].interest) //In case of the value is superior to its neighbour.
                    {
                        sortedList.Insert(i, sortedList[i + 1]); // Insert at its order a new vincinity equal to the neighbour.

                        sortedList.RemoveAt(i + 2); // Remove the neighbour because we insert a new one at the right order.

                        isValid = false; // because we modified something, we need at least one more loop to check everything it's ok.
                    }
                }
            }
        }

        return sortedList; // return the list sorted.
    }
}
