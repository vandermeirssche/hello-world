﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RardarTest : MonoBehaviour {

    private Vector2 radar;

    public float incrementation = 4;

    public float evo;

    public GameObject target;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        RadarScanTest();

        transform.localPosition = radar;

        Debug.DrawLine(transform.position, target.transform.position, Color.red);
    }

    public void RadarScanTest()
    {
        evo += incrementation * Time.deltaTime;

        if (Mathf.Abs(evo) > 4)
            evo = 0;

        radar = new Vector2(Mathf.Sin(evo * Mathf.PI / 2)*3, Mathf.Cos(evo * Mathf.PI / 2)*3);
    }
}
