﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    public class HeroIaInfo : Characters
    {
        [Header("States")]
        /// <summary>
        /// Does the Hero get a target ?
        /// </summary>
        [SerializeField] private bool hasTarget = false;
        /// <summary>
        /// PARAMETER : Does the Hero get a target ?
        /// </summary>
        public bool HasTarget { get { return hasTarget; } set { hasTarget = value; } }

        /// <summary>
        /// Is the Hero inspecting his target ?
        /// </summary>
        [SerializeField] private bool isInspecting = false;
        /// <summary>
        /// PARAMETER : Is the Hero inspecting his target ?
        /// </summary>
        public bool IsInspecting { get { return isInspecting; } set { isInspecting = value; } }

        /// <summary>
        /// Is the Hero hesitating ?
        /// </summary>
        [SerializeField] private bool isHesitating = false;
        /// <summary>
        /// PARAMETER : Is the Hero hesitating ?
        /// </summary>
        public bool IsHesitating { get { return isHesitating; } set { isHesitating = value; } }

        /// <summary>
        /// Is the Hero moving ?
        /// </summary>
        [SerializeField] private bool heroIsMoving;
        /// <summary>
        /// PARAMETER : Is the Hero moving ?
        /// </summary>
        public bool HeroIsMoving { get { return heroIsMoving; } set { heroIsMoving = value; } }

        [Header("Spacial Informations")]
        /// <summary>
        /// Distance between the Hero and his target
        /// </summary>
        [SerializeField] private float distanceFromTarget;
        /// <summary>
        /// PARAMETER : Distance between the Hero and his target
        /// </summary>
        public float DistanceFromTarget { get { return distanceFromTarget; } set { distanceFromTarget = value; } }

        /// <summary>
        /// Direction vector based on the Hero's position and his target's position
        /// </summary>
        [SerializeField] private Vector2 direction;
        /// <summary>
        /// PARAMETER : Direction vector based on the Hero's position and his target's position
        /// </summary>
        public Vector2 Direction { get { return direction; } set { direction = value; } }

        /// <summary>
        /// Hero's speed
        /// </summary>
        [SerializeField] private float heroSpeed;
        /// <summary>
        /// PARAMETER : Hero's speed
        /// </summary>
        public float HeroSpeed
        {
            get { return heroSpeed; }
            set
            {
                if (HeroSpeed > 7)
                    heroSpeed = 7;
                else
                    heroSpeed = value;
            }
        }

        /// <summary>
        /// Hero's facing direction
        /// </summary>
        [SerializeField] private FacingDirection heroFacingDirection;
        /// <summary>
        /// PARAMETER : Hero's facing direction
        /// </summary>
        public FacingDirection HeroFacingDirection { get { return heroFacingDirection; } set { heroFacingDirection = value; } }

        [Header("IA")]
        /// <summary>
        /// Hero's target
        /// </summary>
        [SerializeField] private GameObject heroTarget;
        /// <summary>
        /// PARAMETER : Hero's target
        /// </summary>
        public GameObject HeroTarget { get { return heroTarget; } set { heroTarget = value; } }
        public EntityInformation HeroTargetInformation { get { return heroTarget.GetComponent<EntityInformation>(); } }

        /// <summary>
        /// player Game Object
        /// </summary>
        [SerializeField] private GameObject playerGameObject;
        /// <summary>
        /// PARAMETER : player Game Object
        /// </summary>
        public GameObject PlayerGameObject { get { return playerGameObject; } set { playerGameObject = value; } }

        /// <summary>
        /// Calculated inspecting time
        /// </summary>
        [SerializeField] private float waitingTimeInspecting;
        /// <summary>
        /// PARAMETER : Calculated inspecting time
        /// </summary>
        public float WaintingTimeInspecting { get { return waitingTimeInspecting; } set { waitingTimeInspecting = value; } }

        /// <summary>
        /// List of the vincinities information of the entities.
        /// </summary>
        [SerializeField] private List<Vincinity> vincinities = new List<Vincinity>();
        /// <summary>
        /// PARAMETER : List of the vincinities information of the entities.
        /// </summary>
        public List<Vincinity> Vincinities { get { return vincinities; } set { vincinities = value; } }

        [Header("Components")]
        /// <summary>
        /// Animator of the Hero
        /// </summary>
        [SerializeField] private Animator heroAnimator;

        /// <summary>
        /// Pathfinding script of the Hero.
        /// </summary>
        [SerializeField] private HeroPathfinding heroPathfiding;

        private void Awake()
        {
            heroTarget = gameObject; // Require to avoid a null excpetion.
        }

        void Update()
        {

            if (!IsHesitating)
            {
                if(heroPathfiding.IsPathAvailable)
                    HeroDirection(direction);

                HandleLayers(heroAnimator, "HeroWalkLayer", "HeroIdleLayer", heroIsMoving, HeroFacingDirection, heroSpeed / 2);
            }

            if(heroIsMoving && Random.Range(0f, 5f) > 4.98f )
                Nani();
        }

        /// <summary>
        /// Figure out the facing direction of the Hero is facing.
        /// </summary>
        /// <param name="dir">Direction to check.</param>
        public void HeroDirection(Vector2 dir)
        {
            if (dir.y > 0 && Mathf.Abs(dir.y) > Mathf.Abs(dir.x))
            {
                heroFacingDirection = FacingDirection.North; // North
            }

            if (dir.x > 0 && Mathf.Abs(dir.x) > Mathf.Abs(dir.y))
            {
                heroFacingDirection = FacingDirection.East; // East
            }

            if (dir.y < 0 && Mathf.Abs(dir.y) > Mathf.Abs(dir.x))
            {
                heroFacingDirection = FacingDirection.South; // South
            }

            if (dir.x < 0 && Mathf.Abs(dir.x) > Mathf.Abs(dir.y))
            {
                heroFacingDirection = FacingDirection.West; // West
            }
        }

        /// <summary>
        /// Calculate the Direction of the Hero.
        /// </summary>
        public void CalculateDirection()
        {
            Direction = HeroTarget.transform.position - transform.position;
        }

        public float CalculateWaitingTimeInspecting()
        {
            float factorA = 0.4f;
            if (HasTarget)
                return HeroTargetInformation.VincinityInfo.interestValue * factorA;
            else
                return 0;
        }

        /// <summary>
        /// COROUTINE of inspection. Use HeroIsMoving, IsInspecting, VincinityInfo.Visited, HasTarget.
        /// </summary>
        /// <returns></returns>
        public IEnumerator Inspecting()
        {
            HeroIsMoving = false;

            IsInspecting = true;

            yield return new WaitForSeconds(CalculateWaitingTimeInspecting());

            IsInspecting = false;
            HeroTargetInformation.VincinityInfo.visited = true;
            HasTarget = false;
        }

        /// <summary>
        /// Verify if the Hero is close enough to inspect the target.
        /// </summary>
        /// <returns></returns>
        public bool AbleToInspectTarget()
        {
            //Verify if the hero has a target, if the target isn't the player, if the distance is close enough, and if the Hero isn't inspecting.
            if (HasTarget && HeroTarget.name != "Player" && DistanceFromTarget < 1.5 && !IsInspecting )
                return true;
            else
                return false;
        }

        public override void PlayerActivity()
        {
            StopCoroutine(Inspecting());

            GetComponent<HeroPerceptions>().DetectVincinityEntities();
        }

        /// <summary>
        /// Hesitating coroutine, during a random time in the range [min, max].
        /// </summary>
        /// <param name="min">Minimum hesitating time.</param>
        /// <param name="max">Maximum hesitating time.</param>
        /// <returns></returns>
        public IEnumerator Hesitating(float min, float max) // NEEDS TO BE OPTIMIZED /!\ /!\ /!\
        {
            float maxTime = Random.Range(min, max); // Pick a random value for the hesitating time.

            heroIsMoving = false; // Reset the value.

            IsHesitating = true; // Set the value to true to avoid interferences with other scripts.

            for (float i = 0; i < maxTime; i += Random.Range(min / 2, max / 2.5f)) // The hero will change his direction to fake hesitation. The number of changes and the delay is defined by this loop.
            {
                HeroFacingDirection = (FacingDirection)Random.Range(0, 3); // Chose a random direction in the enumerator FacingDirection.

                heroAnimator.SetFloat("x", CalculateOrientation(HeroFacingDirection).x); // Set the float x of the animator to the x of the calculated orientation.

                heroAnimator.SetFloat("y", CalculateOrientation(HeroFacingDirection).y); // Set the float y of the animator to the y of the calculated orientation.

                ActivateLayer("HeroIdleLayer", heroAnimator); // Activate the idle layer of the hero.

                yield return new WaitForSecondsRealtime(i); // Wait during i seconds.
            }

            CalculateDirection();

            HeroDirection(direction);

            //Fake to look in the direction of his target for a while before moving towards.
            heroAnimator.SetFloat("x", CalculateOrientation(HeroFacingDirection).x); // Set the float x of the animator to the x of the calculated orientation.

            heroAnimator.SetFloat("y", CalculateOrientation(HeroFacingDirection).y); // Set the float y of the animator to the y of the calculated orientation.

            ActivateLayer("HeroIdleLayer", heroAnimator); // Activate the idle layer of the hero.

            yield return new WaitForSecondsRealtime(maxTime/ 2); // wait a little

            IsHesitating = false; // stop hesitating.
        }

        /// <summary>
        /// Function that makes the hero hesitate somtimes while moving.
        /// </summary>
        public void Nani()
        {
            StartCoroutine(Hesitating(0.5f, 1.5f)); // hesitate a little

            if(Random.value > 0.5) // Has 1 chance out of 2 to reconsider his target.
                GetComponent<HeroPerceptions>().DetectVincinityEntities();
        }

        /// <summary>
        /// Verify if there is no obstacles between two positions.
        /// </summary>
        /// <param name="posA">First position.</param>
        /// <param name="posB">Second position.</param>
        /// <returns></returns>
        public bool CheckAccessibility(Vector2 posA, Vector2 posB)
        {
            Vector2 dir = posB - posA; // Define the direction dir to cast a raycast.

            RaycastHit2D hit = Physics2D.Raycast(posA, dir.normalized, Vector2.Distance(posA, posB), LayerMask.GetMask("pathfindCollider")); // raycast between the two position, in the layermask pathfindCollider.

            if (hit.collider == null) // return true if hits nothing.
                return true;

            return false; // Return false otherwise.
        }

        /// <summary>
        /// Calculate the distance between the Hero and the target.
        /// </summary>
        public void CalculateDistanceFromTarget()
        {
            DistanceFromTarget = Vector3.Distance(transform.position, HeroTarget.transform.position);
        }

        /// <summary>
        /// Check if the Player is doing something that will interrupt the Hero.
        /// </summary>
        /// <returns></returns>
        public bool PlayerEntriesVerification()
        {
            //Verify if the Hero got the Player as target and the Player disapeared. In this case, we need the Hero to reset his target.
            if (!PlayerGameObject.GetComponent<PlayerController>().PlayerIsPhysical && HeroTarget.name == "Player") // If the Player IS NOT physical AND the target of the Hero IS the Player.
            {
                return true;
            }

            // Verify if the Hero didn't get the Player as target, and the player appeared. in this case, we need the hero to reset his target.
            if (PlayerGameObject.GetComponent<PlayerController>().PlayerIsPhysical && HeroTarget.name != "Player") // If the Player IS physical AND the target of the Hero IS NOT the Player.
            {
                return true;
            }

            // return False, if the conditions are not verified.
            return false;
        }
    }
}