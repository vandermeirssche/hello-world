﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    public class HeroCharacter : Entity
    {
        /* ONLY FOR THE HERO
         * This script manages the actions of the Hero.
         */

        /// <summary>
        /// Script of the Hero's AI.
        /// </summary>
        [SerializeField] private HeroIaInfo heroIaInfo;

        /// <summary>
        /// Script of the Hero's Pathfinding.
        /// </summary>
        [SerializeField] private HeroPathfinding heroPathfiding;

        /// <summary>
        /// Index of the pathfinding's steps.
        /// </summary>
        [SerializeField] private int pathfindingStepIndex;

        /// <summary>
        /// PARAMETER : Verify if the Hero is able to move.
        /// </summary>
        private bool CheckAbleToMove
        {
            get
            {
                //Check if the Hero has a target, isn't inspecting, and isn't hesitating.
                if (heroIaInfo.HeroTarget.name != heroIaInfo.name && !heroIaInfo.IsInspecting && heroIaInfo.HasTarget && !heroIaInfo.IsHesitating)
                    return true;
                else
                    return false;
            }
        }

        void Update()
        {
            heroIaInfo.HeroIsMoving = false; // Reinitialize the var checking the Hero's movement, to help to interrupt his actions.

            InspectingCoroutine(); 

            // FOR DEBUG ONLY
            heroIaInfo.HeroSpeed = CalculateHeroSpeed(heroIaInfo.HeroTargetInformation.VincinityInfo.interestValue);

            HeroMove();
        }

        /// <summary>
        /// Movement of the Hero without pathfinding.
        /// </summary>
        public void HeroMove()
        {
            if(CheckAbleToMove)
            {
                heroIaInfo.CalculateDirection();

                // Verify whether the Hero needs to use the pathfinding algorithm because of an obstacle or not.
                if (!heroIaInfo.CheckAccessibility(transform.position, heroIaInfo.HeroTarget.transform.position))
                {
                    //Verify if a path is available. If it's not, it will calculate one.
                    if (heroPathfiding.IsPathAvailable)
                        FollowPathfinding();
                    else
                        heroPathfiding.FindPath(Physics2D.Raycast(transform.position, (heroIaInfo.HeroTarget.transform.position - transform.position).normalized, Vector2.Distance(transform.position, heroIaInfo.HeroTarget.transform.position), LayerMask.GetMask("pathfindCollider")).point, heroIaInfo.HeroTarget.transform.position);
                }
                else
                {
                    transform.position = Vector3.MoveTowards(transform.position, heroIaInfo.HeroTarget.transform.position, heroIaInfo.HeroSpeed * Time.deltaTime); // Move towards the target's position.
                }

                heroIaInfo.HeroIsMoving = true; // Announce that the player is moving.
            }
        }

        /// <summary>
        /// Calculate the speed of the Hero based on the interest of his target.
        /// </summary>
        /// <param name="interest"></param>
        /// <returns></returns>
        public float CalculateHeroSpeed(float interest)
        {
            float factorA = 0.4f; // Set up a factor linked to the interest.
            float baseSpeed = 3.0f; // set up the base Hero's speed.

            float speed = baseSpeed + interest * factorA; // Calculate the Speed.

            // Cap the speed to 7.
            if (speed > 7)
                speed = 7;

            return speed;
        }

        /// <summary>
        /// Verify if it's OK to inspect, and to stop moving.
        /// </summary>
        public void InspectingCoroutine()
        {
            if (heroIaInfo.AbleToInspectTarget())
                StartCoroutine(heroIaInfo.Inspecting());
        }

        /// <summary>
        /// Set up the path of the Hero using the calculation of the pathfinding script.
        /// </summary>
        public void FollowPathfinding()
        {
            Vector3 currentWaypoint = heroPathfiding.Waypoints[pathfindingStepIndex]; // Get the current waypoint of the path calculating.

            float adjustPos = 0.25f; // Adjust the position in the center of the square

            Debug.DrawLine(transform.position, new Vector2(heroPathfiding.Waypoints[pathfindingStepIndex].x + adjustPos, heroPathfiding.Waypoints[pathfindingStepIndex].y + adjustPos), Color.magenta); // Draw a magenta line between the Hero and the current waypoint.

            //Cycle all the visible waypoints, to skip them. This way the Hero will manage to go to the farest waypoint he can see.
            while (pathfindingStepIndex < heroPathfiding.Waypoints.Count && heroIaInfo.CheckAccessibility(transform.position, new Vector2(heroPathfiding.Waypoints[pathfindingStepIndex].x + adjustPos, heroPathfiding.Waypoints[pathfindingStepIndex].y + adjustPos)))
            {
                pathfindingStepIndex++;
            }

            // Verify the step index is not out of the range of the waypoints list.
            if (pathfindingStepIndex < heroPathfiding.Waypoints.Count)
            {
                float dist = Vector3.Distance(new Vector3(currentWaypoint.x + adjustPos, currentWaypoint.y + adjustPos, 0), transform.position); // measure the distance between the Hero and the current waypoint.

                // Verify that the Hero reached the waypoint.
                if (dist < 0.1f)
                {
                    pathfindingStepIndex++; // increment the step index.

                    currentWaypoint = heroPathfiding.Waypoints[pathfindingStepIndex]; // Get the new waypoint as the current waypoint.

                }

                transform.position = Vector3.MoveTowards(transform.position, new Vector3(currentWaypoint.x + adjustPos, currentWaypoint.y + adjustPos, 0), heroIaInfo.HeroSpeed * Time.deltaTime); // Move the Hero to the current waypoint.

                // BUG SA MERE LA TCHOIN !!! In conflict with line 64 of this script.
                heroIaInfo.HeroDirection(new Vector2(currentWaypoint.x - transform.position.x, currentWaypoint.y - transform.position.y) ); // Set the new facing direction of the Hero.

            }
            else // If the index is out of range, that means we hit the end of the path.
            {
                heroPathfiding.IsPathAvailable = false; // Deactivate the path.

                pathfindingStepIndex = 0; // Reinitialize the step index.

                // À TEJ PARCE QUE PAS OPTI
                StartCoroutine(heroIaInfo.Inspecting()); // Starts inspecting.
            }
        }
    }
}
