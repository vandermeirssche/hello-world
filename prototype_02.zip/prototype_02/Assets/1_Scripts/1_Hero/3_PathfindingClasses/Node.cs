﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;


namespace ZeldaLike.Vadnir
{
    /// <summary>
    /// Class used to store pathfinding information from tiles.
    /// </summary>
    public class Node : IHeapItem<Node>
    {
        /// <summary>
        /// Is the node walkable ?
        /// </summary>
        public bool walkable;

        /// <summary>
        /// Node's position into the tilemap's context.
        /// </summary>
        public Vector3Int tilemapPosition;

        /// <summary>
        /// Node's position into the world's context.
        /// </summary>
        public Vector3 worldPosition;

        /// <summary>
        /// Tilemap of the node.
        /// </summary>
        public Tilemap tilemap;

        /// <summary>
        /// G Cost of the Node. Weight of the distance between the Start and the node.
        /// </summary>
        public int gCost;

        /// <summary>
        /// H Cost of the node. Weight of the distance between the End and the node.
        /// </summary>
        public int hCost;

        /// <summary>
        /// F Cost of the node. Weight of the node, which is the sum of the H cost and the G cost.
        /// </summary>
        public int FCost { get { return gCost + hCost; } }

        //TEST
        private int heapIndex;
        public int HeapIndex { get { return heapIndex; } set { heapIndex = value; } }

        /// <summary>
        /// x position of the Node according to the tilemap.
        /// </summary>
        public int x;

        /// <summary>
        /// y position of the Node according to the tilemap.
        /// </summary>
        public int y;

        /// <summary>
        /// z position of the Node according to the tilemap. Kind of useless shit.
        /// </summary>
        public int z;

        /// <summary>
        /// Parent Node of the Node. Used to retrace the full path.
        /// </summary>
        public Node parent;

        /// <summary>
        /// Method to call a new node.
        /// </summary>
        /// <param name="tm">Tilemap of the node.</param>
        /// <param name="pos">Position in the tilemap of the node.</param>
        public Node(Tilemap tm, Vector3Int pos)
        {
            walkable = !tm.HasTile(pos); // Set the Node as walkable if there is no tile at its position in the tilemap.

            tilemapPosition = pos; // Set the position of the Node in the tilemap.

            x = tilemapPosition.x; // Set node.x.

            y = tilemapPosition.y; // Set node.y.

            z = tilemapPosition.z; // Set node.z.

            worldPosition = tm.CellToWorld(pos); // Set the world position of the Node.
        }

        public int CompareTo(Node nodeToCompare) // CompareTo method of the class. useless shit now.
        {
            int compare = FCost.CompareTo(nodeToCompare.FCost);

            if (compare == 0)
            {
                compare = hCost.CompareTo(nodeToCompare.hCost);
            }

            return -compare;
        }
        
    }
}
