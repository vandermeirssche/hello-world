﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics; // Required to use the Stopwatch.
using UnityEngine;
using UnityEngine.Tilemaps;


namespace ZeldaLike.Vadnir
{
    public class HeroPathfinding : Entity
    {
        /* FOR THE HERO CHARACTER ONLY (for now :p )
         * This script calcuate a path between an start position and an end position. This path can avoid obstacles, but it use a lot of memory in some cases. Use it with caution !
         * The algorithm works with a tilemap. It will assign value to each tilie it needs to test and get a path using those values.
         * The more the tilemap scale is small, the more, the path is precise, but the more it will takes memory and time to calculate it.
         */

        /// <summary>
        /// Tilemap used to delimitate obstacles.
        /// </summary>
        [SerializeField] private Tilemap obstaclesTilemap;

        /// <summary>
        /// Debug tilemap used to show the calculated path.
        /// </summary>
        [SerializeField] private Tilemap pathTilemap;

        /// <summary>
        /// Position of the agent.
        /// </summary>
        [SerializeField] private Transform agent;

        /// <summary>
        /// Position of the targeted location.
        /// </summary>
        [SerializeField] private Transform target;

        /// <summary>
        /// List that will stock all the waypoints calculated.
        /// </summary>
        private List<Vector3> waypoints = new List<Vector3>();
        /// <summary>
        /// PARAMETER : List that will stock all the waypoints calculated.
        /// </summary>
        public List<Vector3> Waypoints { get { return waypoints; } set { waypoints = value; } }

        /// <summary>
        /// Is a path available ?
        /// </summary>
        [SerializeField] private bool isPathAvailable;
        /// <summary>
        /// PARAMETER : is a pathe available ?
        /// </summary>
        public bool IsPathAvailable { get { return isPathAvailable; } set { isPathAvailable = value; } }

        /// <summary>
        /// Intermediate list of waypoints.
        /// </summary>
        [SerializeField] private List<Node> path;

        // DEBUG TILES
        public TileBase openTile;
        public TileBase closedTile;
        public TileBase testTile;

        /// <summary>
        /// Find a path between a starting position and an ending position.
        /// </summary>
        /// <param name="startPos">Starting position</param>
        /// <param name="targetPos">Ending position</param>
        public void FindPath(Vector3 startPos, Vector3 targetPos)
        {
            Stopwatch sw = new Stopwatch(); // used for Debug : it will calculate how many milliseconds it takes to calculate the path.

            sw.Start(); // Starting the stopwatch.

            Vector3[] waypoints = new Vector3[0]; // Initialize the waypoints list.

            bool pathSucces = false; // set a bool to test whether the path is find or not.

            Node startNode = new Node(obstaclesTilemap, obstaclesTilemap.WorldToCell(startPos)); // Translate the starting position into a Node class.

            Node targetNode = new Node(obstaclesTilemap, obstaclesTilemap.WorldToCell(targetPos)); // Translate the target position into a Node class.

            List<Node> openSet = new List<Node>(); // Initialize a list of Node set as open, which means that the algorithm would still calculate a path from them.

            List<Node> closedSet = new List<Node>(); // Initialize a list of Node set as closed, which means that the algorithm would not calculate anymore path from them.

            openSet.Add(startNode); // Add the starting Node to the open list.

            Node currentNode = startNode; // Set up a current Node which starts to be the starting Node.

            //The algorithm will loop until it reaches the ending Node, or until there is no more open Node.
            //This is the main loop which breaks when it reaches the ending Node, or stop to loop when the openSet list is empty.
            while (openSet.Count > 0) // So while there are open Nodes
            {
                Node node = openSet[0]; // We will handle this node during the cycle of the loop.

                // We manage to get the smallest F cost value.
                for (int i = 1; i < openSet.Count; i++) // Cycle all the open Nodes.
                {
                    if (openSet[i].FCost < node.FCost || openSet[i].FCost == node.FCost) // Test if the F cost of the tested node is less or equal or less than the actual node's one.
                    {
                        if (openSet[i].hCost < node.hCost) // test if the H cost is smaller.
                            node = openSet[i]; // In this case, we use the new node.
                    }
                }

                openSet.Remove(node); // Remove the node from the open list.

                closedSet.Add(node); // Add the node to the closed list. This means that the node is calculated, and we don't have to reuse it.

                if (node.tilemapPosition == targetNode.tilemapPosition) // if the node is the ending node
                {
                    sw.Stop(); // Stop the debug Stopwatch

                    UnityEngine.Debug.Log("Chemin trouvé en : " + sw.ElapsedMilliseconds + "ms"); // return the time it takes to get there. We need to put UnityEngine because System.Diagnostics also use a Debug class.

                    pathSucces = true; // Announce that the path is found.

                    currentNode = node; // set the current node to the actual node.

                    break; // Break out from the while loop.
                }

                //otherwise, the algorithm set a weight to the node's neighbours.
                foreach (Node neighbour in GetNeighbours(node)) // test each neighbour.
                {
                    if (!neighbour.walkable || Contains(closedSet, neighbour)) // verify if the neighbour is an obstacle or already closed
                    {
                        //pathTilemap.SetTile(neighbour.tilemapPosition, closedTile); // FOR DEBUG : display the closed tiles on the debug tilemap.

                        continue; // In this case we skip the remaining code of the foreach loop.
                    }

                    int newCostToNeighbour = node.gCost + GetDistance(node, neighbour); // Calculate a new G cost.

                    if (newCostToNeighbour < neighbour.gCost || !Contains(openSet, neighbour)) // verify the new G cost is smaller than the node's g cost or if the node isn't open.
                    {
                        neighbour.gCost = newCostToNeighbour; // Update the node's G cost with the new one.

                        neighbour.hCost = GetDistance(neighbour, targetNode); // set the H cost of the neighbour.

                        neighbour.parent = node; // Set the actuale node as the parent of the neighbour. This will be used to retrace the whole path when it hits the target position.

                        if (!Contains(openSet, neighbour)) // In the case the node wasn't already registered.
                        {
                            //pathTilemap.SetTile(neighbour.tilemapPosition, openTile); // FOR DEBUG : display the open tiles on the debug tilemap.

                            openSet.Add(neighbour); // Add the neighbour to the open list.
                        }
                    }
                }
            }

            if (pathSucces) // verify the algorithm found a path.
            {
                RetracePath(startNode, currentNode); // retrace the whole path using parents.
            }

        }

        /// <summary>
        /// Set up a list of nodes next to the tested node.
        /// </summary>
        /// <param name="node">tested node.</param>
        /// <returns></returns>
        public List<Node> GetNeighbours(Node node)
        {
            List<Node> neighbours = new List<Node>(); // Initialize the list of neighbouring nodes.

            for (int x = -1; x <= 1; x++) // Neighbours x value are -1, 0, and 1. This cycle those values.
            {
                for (int y = -1; y <= 1; y++) // Neighbours y value are -1, 0, and 1. This cycle those values.
                {
                    if (x == 0 && y == 0) // at 0,0 coordinates it's the tested node.
                        continue; // Skip the tested node.

                    int checkX = node.x + x;

                    int checkY = node.y + y;

                    if((Mathf.Abs(checkX) >= 0 && Mathf.Abs(checkX) < 400)&&(Mathf.Abs(checkY) >= 0 && Mathf.Abs(checkY) < 400))
                        neighbours.Add(new Node(obstaclesTilemap, new Vector3Int(node.x + x, node.y + y, node.z))); // Add to the list a node with coordinates based on the tested node's.
                }
            }

            return neighbours; // Return the neighbours list.
        }

        /// <summary>
        /// Caluclate the weight of the distance between two Nodes. When the path is vertical or horizontal, the weight adds 10. When it's a diagonal it adds 14.
        /// </summary>
        /// <param name="nodeA">First node.</param>
        /// <param name="nodeB">Second node.</param>
        /// <returns></returns>
        int GetDistance(Node nodeA, Node nodeB)
        {
            int distanceX = Mathf.Abs(nodeA.x - nodeB.x); // Get the distance between the to Nodes, in the x axis.

            int distanceY = Mathf.Abs(nodeA.y - nodeB.y); // Get the distance between the two Nodes, in the y axis.

            if (distanceX > distanceY)
                return 14 * distanceY + 10 * (distanceX - distanceY); // Calculates the weight if the distance of the X axis is higher than the Y axis one's.
            
            return 14 * distanceX + 10 * (distanceY - distanceX); // Calculates the weight if the distance of the Y axis is higher than the X axis one's.
        }

        /// <summary>
        /// Use the parenthood between nodes to retrace the better path between a strating node and the ending node.
        /// </summary>
        /// <param name="startNode">Starting node.</param>
        /// <param name="endNode">Ending node.</param>
        public void RetracePath(Node startNode, Node endNode)
        {
            List<Node> path = new List<Node>(); // Initialize a new list which get the whole path.

            waypoints = new List<Vector3>(); // Reinitialize the waypoints list.

            Node currentNode = endNode; // set a current node, and starts by the end.

            while(currentNode != startNode) // Loop until it reaches the starting node.
            {
                path.Add(currentNode); // Add the current node to the path.

                currentNode = currentNode.parent; // then test the parent node

                pathTilemap.SetTile(currentNode.tilemapPosition, testTile); // FOR DEBUG : display the good tiles on the debug tilemap.

            }

            path.Reverse(); // Reverse the path to the right way.

            this.path = path; // JE SAIS PLUS POURQUOI J'AI FAIT ÇAAAAAAAAAAAAAAAAAAAAAAAAA T-T

            for (int i = 0; i < path.Count; i++) // Cycle all the nodes to get their world position.
            {
                waypoints.Add(path[i].worldPosition); // Add the new waypoint to the list.
            }

            isPathAvailable = true; // Announce the path is available.

            // UnityEngine.Debug.Log(IsPathAvailable);
        }

        /// <summary>
        /// TEST : Method to verify if the node exists in the heap method.
        /// </summary>
        /// <param name="heap">Heap</param>
        /// <param name="node">Node tested</param>
        /// <returns></returns>
        bool Contains(Heap<Node> heap, Node node)
        {

            for (int i = 0; i < heap.Count ; i++)
            {
                if (heap.Index(i).tilemapPosition == node.tilemapPosition)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Verify the tested node exists in the List of nodes.
        /// </summary>
        /// <param name="list">List of nodes</param>
        /// <param name="node">Tested node</param>
        /// <returns></returns>
        bool Contains(List<Node> list, Node node)
        {

            for (int i = 0; i < list.Count; i++) // Cycle the whole list
            {
                if (list[i].tilemapPosition == node.tilemapPosition)
                    return true; // return true if it matches.
            }

            return false; // return false if it there is no match.
        }

        /// <summary>
        /// Find a path between a starting position and an ending position. Overload using Transform.
        /// </summary>
        /// <param name="startPos">Starting position</param>
        /// <param name="targetPos">Ending position</param>
        public void FindPath(Transform startPos, Transform targetPos)
        {
            Vector3 startPosV3 = startPos.position; //Translate Transform to Vector3

            Vector3 targetPosV3 = targetPos.position; //Translate Transform to Vector3

            FindPath(startPos, targetPos); // Use the overload with Vector3
        }
    }
}
