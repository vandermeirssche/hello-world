﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ZeldaLike.Vadnir
{
    public class HeroPerceptions : MonoBehaviour
    {
        /* ONLY FOR THE HERO
         * This script detects the vincinity information, and send them to the HeroIaInformation's script
         * of the hero's gameObject.
         */

        /// <summary>
        /// View Radius of the Hero.
        /// </summary>
        [SerializeField] private float heroViewRadius = 20;
        /// <summary>
        /// PARAMETER : View Radius of the Hero.
        /// </summary>
        public float HeroViewRadius { get { return heroViewRadius; } set { heroViewRadius = value; } }

        /// <summary>
        /// List stocking all the entities in the Hero's FOV.
        /// </summary>
        [SerializeField]private Collider2D[] entitiesInViewRadius;
        /// <summary>
        /// PARAMETER : List stocking all the entities in the Hero's FOV.
        /// </summary>
        public Collider2D[] EntitesInViewRadius { get { return entitiesInViewRadius; } set { entitiesInViewRadius = value; } }

        /// <summary>
        /// Script of the Hero's AI.
        /// </summary>
        [SerializeField] private HeroIaInfo heroIaInfo;

        /// <summary>
        /// Script of the Hero's Pathfinding.
        /// </summary>
        [SerializeField] private HeroPathfinding heroPathfiding;

        void Update()
        {
            //Limit the detection of entities to those conditions
            if((!heroIaInfo.HasTarget || heroIaInfo.PlayerEntriesVerification()) && !heroIaInfo.IsHesitating)
            {
                DetectVincinityEntities();
            }

            heroIaInfo.CalculateDistanceFromTarget();

            //Draw a blue line between the target of the Hero and the Hero himself. The color changes to BLACK if there is an obstacle in the way.
            Debug.DrawLine(transform.position, heroIaInfo.HeroTarget.transform.position, heroIaInfo.CheckAccessibility(transform.position, heroIaInfo.HeroTarget.transform.position) ? Color.blue : Color.black);


        }

        /// <summary>
        /// Called to Detect the entities in the vincinity.
        /// </summary>
        public void DetectVincinityEntities()
        {
            heroIaInfo.Vincinities = new List<Vincinity>(); // Initialize the list of elements in the vincinty.
            
            GetEntitiesInViewRadius(); // Detect entities.

            ChoseTarget(); // Select a target in the whole list of entities in the vincinity.
        }

        /// <summary>
        /// OLD : Used to detect entities in the vincinity from multiple ways.
        /// </summary>
        public void DetectVisibleEntities()
        {
            GetEntitiesInViewRadius();
        }

        /// <summary>
        /// Used to detect entities in the vincinity in one way.
        /// </summary>
        public void GetEntitiesInViewRadius()
        {
            entitiesInViewRadius = Physics2D.OverlapCircleAll(transform.position, heroViewRadius, LayerMask.GetMask("Entities")); // Get the list of all collider2D in the radius.

            GetInformationFromEntities(entitiesInViewRadius, heroIaInfo.Vincinities); // Translate those colliders 2D into vincinities objects in the list heroIaInfo.Vincinities.

            heroIaInfo.Vincinities.SortByVincinityComparator(VincinityComparator.Interest); // Sort the Vincinities by interest.
        }

        /// <summary>
        /// Translate Colliders2D into the list of detected vincinities.
        /// </summary>
        /// <param name="listOfEntities">Collider2D array detected.</param>
        /// <param name="entities">List of detected entities.</param>
        public void GetInformationFromEntities(Collider2D[] listOfEntities, List<Vincinity> entities)
        {
            for (int i = 0; i < listOfEntities.Length; i++) // Cycle all the collider2D detected
            {
                Debug.DrawLine(transform.position, listOfEntities[i].transform.position, Color.red); // Draw a red line between the Hero and the position of the object with the collider2D.

                if(!listOfEntities[i].GetComponent<EntityInformation>().VincinityInfo.visited)  // Test if the object had already been visitied. If not : 
                {
                    Debug.DrawLine(transform.position, listOfEntities[i].transform.position, Color.green); // Draw a green line between the Hero and the position of the collider2D (it remplaces the red line).

                    entities.Add(listOfEntities[i].GetComponent<EntityInformation>().VincinityInfo); // Add the object collided to the list.
                }
            }
        }

        /// <summary>
        /// Pick a target
        /// </summary>
        public void ChoseTarget()
        {
            heroPathfiding.IsPathAvailable = false; // Verify if a path from the pathfinding script exists.

            int listLength = heroIaInfo.Vincinities.Count;
            
            if(listLength > 3) // Select randomly the target if there is enough choice.
            {
                //Pick a random number between 0 and the sum of the trhee highest interest values.
                float alea = Random.Range(0, heroIaInfo.Vincinities[listLength - 1].interest + heroIaInfo.Vincinities[listLength - 2].interest + heroIaInfo.Vincinities[listLength - 3].interest);

                //Select the target in relation of this random number.
                if (alea < heroIaInfo.Vincinities[listLength - 1].interest)
                    heroIaInfo.HeroTarget = heroIaInfo.Vincinities[listLength - 1].vincinityObject;
                else if (alea < heroIaInfo.Vincinities[listLength - 2].interest)
                    heroIaInfo.HeroTarget = heroIaInfo.Vincinities[listLength - 2].vincinityObject;
                else
                    heroIaInfo.HeroTarget = heroIaInfo.Vincinities[listLength - 3].vincinityObject;
            }
            else
            {
                if(listLength > 0 ) // If there is at least 1 object in the vincinity not visited.
                    heroIaInfo.HeroTarget = heroIaInfo.Vincinities[listLength - 1].vincinityObject; // Chose the object with the highest interest.
                else // If there is no object in the vincinity
                {
                    heroIaInfo.HeroTarget = gameObject; // Reset the hero's target with its own gameObject.

                    heroIaInfo.HasTarget = false; // Set the bool checking if it has a target to false.
                }
            }

            // Use an hesistating coroutine to mimic a human behaviour.
            if (!heroIaInfo.IsHesitating) //Check if it's not already hesitating.
                StartCoroutine(heroIaInfo.Hesitating(1, 3.5f)); // Start the coroutine.
        }
    }
}