﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events; // <- On a besoin d'utiliser la librairie des events

public class SomeEventHandlerComponent : MonoBehaviour {


    /*
    public event UnityAction myEvent;

    private void Start()
    {
        myEvent += SomeFunction;
        myEvent += SomeFunction;

        myEvent -= SomeFunction;


        myEvent();
    }
    */
    void SomeFunction()
    {

    }
    

    // Un objet de type UnityEvent est une liste de choses qui vont se produire sous certaines conditions.
    // Dans mon exemple, je veux exposer un callback (= conséquence) qui correspond à l'appui sur la barre Espace.

    public UnityEvent onPressedSpacefgdgfdgljk;
	// ^ ma variable peut s'appeler n'importe comment, on n'est pas sur des calls automatiques de type OnTriggerEnter !

	// Dans l'inspector, la personne chargée de l'intégration accèdera à une interface claire : c'est une liste.
	// Imaginons que je veuille faire jouer des sons, et des particules, en appuyant sur Space.
	// 1. J'ajoute un élément (une conséquence) à la liste, en cliquant sur le "+" en bas à droite
	// 2. Je remplis le champ en y glissant le GameObject qui va réagir. Par exemple, le porteur d'une AudioSource.
	// 3. Dans le menu déroulant qui apparaît, je choisis le composant que je veux faire réagir. Dans mon exemple, AudioSource.
	// 4. Une fois mon composant choisi, j'ai accès à la liste des fonctions publiques dispos. Je choisis Play().

	void Update ()
	{
		if (Input.GetKeyDown(KeyCode.Space)) // Lorsque le joueur appuie sur espace...
		{
			if (onPressedSpacefgdgfdgljk != null) // ...Si la liste des conséquences assignées à l'event n'est pas vide...
			{
				onPressedSpacefgdgfdgljk.Invoke(); // ...Alors j'exécute toutes les fonctions qui y auront été assignées dans l'inspector.
			}
		}	
	}

	// Vos GA sont désormais 100% autonomes sur Unity ! :D
	
	// Ça marche aussi avec les fonctions publiques de vos propres scripts (public void Hello())...
	// ...du moment qu'elles ne prennent pas plus d'un argument (et uniquement int/float/bool/string).
	// Lever cette restriction est possible, ce sera pour un prochain tuto.

	// Bon courage !
}


